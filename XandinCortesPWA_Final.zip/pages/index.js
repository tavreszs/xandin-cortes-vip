
export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center">
      <h1 className="text-4xl font-bold">Xandin Cortes App no ar 🚀</h1>
    </div>
  )
}
